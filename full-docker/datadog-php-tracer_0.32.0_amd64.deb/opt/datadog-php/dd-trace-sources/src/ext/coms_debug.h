#ifndef DD_COMS_TEST_H
#define DD_COMS_TEST_H
#include <stdint.h>

uint32_t ddtrace_coms_test_writers();
uint32_t ddtrace_coms_test_consumer();
uint32_t ddtrace_coms_test_msgpack_consumer();

#endif  // DD_COMS_TEST_H
