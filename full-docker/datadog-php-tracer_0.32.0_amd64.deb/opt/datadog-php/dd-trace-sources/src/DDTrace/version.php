<?php

// Must begin with a number for Debian packaging requirements
// Must use single-quotes for packaging script to work
return '0.32.0'; // Update Tracer::VERSION too
